/*
 * Floor.h
 *
 *  Created on: 26 nov. 2023
 *      Author: agus
 */

#ifndef FLOORMANAGEMENT_FLOOR_H_
#define FLOORMANAGEMENT_FLOOR_H_

#define OFFICE_FLOOR_COUNT	10

static int floor_occupancy[OFFICE_FLOOR_COUNT];



#endif /* FLOORMANAGEMENT_FLOOR_H_ */
