/*
 * open.c
 *
 *  Created on: 3 sep. 2023
 *      Author: agus
 */

#include "open.h"
#include "Drivers/BoardLeds.h"

void five_sec_elapsed_green()
{

}
