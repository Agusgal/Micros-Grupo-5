/*
 * open.h
 *
 *  Created on: 3 sep. 2023
 *      Author: agus
 */

#ifndef _OPEN_H_
#define _OPEN_H_

void five_sec_elapsed_green(void);


#endif /* _OPEN_H_ */
