#ifndef CARD_ENTRY_H
#define CARD_ENTRY_H


void init_cardswipe(void);

void init_failed_cardswipe(void);

void msg_fail_card(void);

void msg_ok_card(void);

void msg_error_card(void);

#endif /* CARD_ENTRY_H */
