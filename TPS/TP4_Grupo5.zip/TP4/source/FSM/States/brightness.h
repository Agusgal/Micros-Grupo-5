/*
 * brightness.h
 *
 *  Created on: 3 sep. 2023
 *      Author: agus
 */

#ifndef _BRIGHTNESS_H_
#define _BRIGHTNESS_H_


void incr_bri(void);
void decr_bri(void);
void bri_message(void);


#endif /* _BRIGHTNESS_H_ */
