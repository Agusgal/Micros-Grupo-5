/*
 * main.c
 *
 *  Created on: May 1, 2015
 *      Author: Juan Pablo VEGA - Laboratorio de Microprocesadores
 */

#include <i2c.h>
#include "hardware.h"
#include <FXOS8700CQ.h>

#define __FOREVER__ 	for(;;)

#define PIN_RED_LED 		22     	//PTB22
#define PIN_BLUE_LED 		21     	//PTB21
#define PIN_GREEN_LED 		26 	   	//PTE26
#define PIN_PUSH_BUTTON  	4 		//PTA4



typedef enum
{
	PORT_eDisabled				= 0x00,
	PORT_eDMARising				= 0x01,
	PORT_eDMAFalling			= 0x02,
	PORT_eDMAEither				= 0x03,
	PORT_eInterruptDisasserted	= 0x08,
	PORT_eInterruptRising		= 0x09,
	PORT_eInterruptFalling		= 0x0A,
	PORT_eInterruptEither		= 0x0B,
	PORT_eInterruptAsserted		= 0x0C,
} PORTEvent_t;

#define BALIZA_DELAY	4000000UL

void idle(void);
void delayLoop (uint32_t veces);

int main (void)
{
	uint8_t read_buffer[20]={0,0};
	uint8_t write_buffer[]={0};
	I2C0_Com(read_buffer,1,write_buffer,0, 0x1D,WHO_AM_I_REG);
	int a =1;
	while(1);
}


